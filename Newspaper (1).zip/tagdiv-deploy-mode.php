<?php

/**
 * dev demo deploy
 */

//dev demo or none
if (!defined('TD_DEPLOY_MODE')) {
    define("TD_DEPLOY_MODE", 'deploy');
}